package com.hbaker;

public enum TimeGroup {
    SECOND,
    MINUTE,
    HOUR,
    DAY,
    MONTH,
    YEAR
}
